package com.example.parking;

public class Locations {
    private String location;

    public Locations(String location) {
        this.location = location;
    }

    public String getAnimalName() {
        return this.location;
    }
}
